define({
  "_themeLabel": "Paleisties klaviatūros tema",
  "_layout_default": "Numatytasis maketas",
  "_layout_right": "Maketas dešinėje"
});