define({
  "_themeLabel": "Тема на пусков панел",
  "_layout_default": "Оформление по подразбиране",
  "_layout_right": "Дясно оформление"
});