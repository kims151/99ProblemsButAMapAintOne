define({
  "_themeLabel": "Palaišanas paneļa tēma",
  "_layout_default": "Noklusējuma izkārtojums",
  "_layout_right": "Pareizais izkārtojums"
});