define({
  "_themeLabel": "快速启动主题",
  "_layout_default": "默认布局",
  "_layout_right": "右侧布局"
});