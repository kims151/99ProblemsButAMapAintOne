define({
  "_widgetLabel": "Verankerungsleisten-Controller",
  "_layout_default": "Standard-Layout",
  "_layout_layout1": "Layout 0",
  "more": "Weitere Widgets"
});